-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Feb 03, 2020 at 11:21 AM
-- Server version: 5.7.26
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cl_ajax`
--

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` int(11) NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `module_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `uri` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `position` int(5) NOT NULL DEFAULT '0',
  `icon` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `is_parent` tinyint(1) NOT NULL DEFAULT '0',
  `show_menu` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `title`, `module_name`, `url`, `uri`, `position`, `icon`, `parent_id`, `is_parent`, `show_menu`) VALUES
(1, 'Dashboard', '', '', 'dashboard', 0, 'fa fa-home menu-item-icon', 0, 0, '1'),
(2, 'Exclusive plugins', '', '', '', 0, 'fa fa-share-alt menu-item-icon', 0, 0, '1'),
(3, 'Graphs', '', '', '', 0, 'fa fa-area-chart menu-item-icon', 0, 0, '1'),
(5, 'LobiPanel', '', '', 'lobipanel', 0, '', 2, 1, '1'),
(6, 'LobiBox', '', '', 'lobibox', 0, '', 2, 1, '1'),
(7, 'LobiTab', '', '', 'lobitab', 0, '', 2, 1, '1'),
(8, 'LobiList', '', '', 'lobilist', 0, '', 2, 1, '1'),
(9, 'Chart.js', '', '', 'chartjs', 0, '', 3, 1, '1'),
(10, 'Morris Charts', '', '', 'morrisjs', 0, '', 3, 1, '1'),
(11, 'Inline Charts', '', '', 'inline-charts', 0, '', 3, 1, '1'),
(12, 'Tables', '', '', '', 0, 'fa fa-table menu-item-icon', 0, 0, '1'),
(13, 'Basic Tables', '', '', 'basic-tables', 0, '', 12, 1, '1'),
(14, 'Data Tables', '', '', 'data-tables', 0, '', 12, 1, '1'),
(15, 'UI Elements', '', '', '', 0, 'fa fa-list-alt menu-item-icon', 0, 0, '1'),
(16, 'Default Elements', '', '', 'default-elements', 0, '', 15, 1, '1'),
(17, 'Icons', '', '', '', 0, '', 15, 1, '1'),
(18, 'Glyphicon', '', '', 'glyphicon', 0, 'glyphicon glyphicon-cloud-download menu-item-icon', 17, 1, '1'),
(19, 'Font Awesome', '', '', 'font-awesome', 0, 'fa fa-flag menu-item-icon', 17, 1, '1'),
(20, 'Weather icons', '', '', 'weather-icons', 0, 'wi wi-cloudy menu-item-icon', 17, 1, '1'),
(21, 'Typography', '', '', 'typography', 0, NULL, 15, 1, '1'),
(22, 'Buttons', '', '', 'buttons', 0, NULL, 15, 1, '1'),
(23, 'Tiles', '', '', 'tiles', 0, NULL, 15, 1, '1'),
(24, 'Discount labels', '', '', 'discount-labels', 0, NULL, 15, 1, '1'),
(25, 'Treeview', '', '', 'treeview', 0, NULL, 15, 1, '1'),
(26, 'Six Level Menu', '', '', '', 0, NULL, 15, 1, '1'),
(27, 'Third level menu', '', '', '', 0, NULL, 26, 1, '1'),
(28, 'Fourth level', '', '', '', 0, NULL, 27, 1, '1'),
(29, 'Fifth level', '', '', '', 0, NULL, 28, 1, '1'),
(30, 'Sixth level', '', '', '', 0, NULL, 29, 1, '1'),
(31, 'Forms', '', '', '', 0, 'fa fa-pencil-square-o menu-item-icon', 0, 0, '1'),
(32, 'Basic Elements', '', '', 'form-basic-elements', 0, NULL, 31, 1, '1'),
(33, 'Custom Elements', '', '', 'form-custom-elements', 0, NULL, 31, 1, '1'),
(34, 'Form Plugins', '', '', 'form-plugins', 0, NULL, 31, 1, '1'),
(35, 'Form Layouts', '', '', 'form-layouts', 0, NULL, 31, 1, '1'),
(36, 'Form Validation', '', '', 'form-validation', 0, NULL, 31, 1, '1'),
(37, 'Wizards', '', '', 'wizard', 0, NULL, 31, 1, '1'),
(38, 'WYSIWYG Editor', '', '', 'editor', 0, NULL, 31, 1, '1'),
(39, 'Image cropping', '', '', 'image-cropping', 0, NULL, 31, 1, '1'),
(40, 'Grid options', '', '', 'grid', 0, 'fa fa-laptop menu-item-icon', 0, 0, '1'),
(41, 'Calendar', '', '', 'calendar', 0, 'fa fa-calendar menu-item-icon', 0, 0, '1'),
(42, 'Inbox', '', '', 'lobimail', 0, 'fa fa-envelope menu-item-icon', 0, 0, '1'),
(43, 'Extra', '', '', '', 0, 'fa fa-file-o menu-item-icon', 0, 0, '1'),
(44, 'Page 404', '', '', 'error-404', 0, NULL, 43, 1, '1'),
(45, 'Page 500', '', '', 'error-500', 0, NULL, 43, 1, '1'),
(46, 'Lock Screen', '', 'lock', '', 0, NULL, 43, 1, '1'),
(47, 'Login & Register', '', 'login', '', 0, NULL, 43, 1, '1'),
(48, 'Helper Classes', '', '', 'helper', 0, NULL, 43, 1, '1'),
(49, 'Pricing tables', '', '', 'pricing-tables', 0, NULL, 43, 1, '1'),
(50, 'Timeline', '', '', 'timeline', 0, NULL, 43, 1, '1'),
(51, 'Invoice', '', '', 'invoice', 0, NULL, 43, 1, '1'),
(52, 'Profile', '', '', 'profile', 0, NULL, 43, 1, '1');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `title` varchar(156) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `title`) VALUES
(1, 'Administration'),
(2, 'Admin'),
(3, 'Manager');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(128) NOT NULL COMMENT 'login email',
  `password` varchar(128) NOT NULL COMMENT 'hashed login password',
  `username` varchar(128) DEFAULT NULL COMMENT 'full name of user',
  `firstname` varchar(156) NOT NULL,
  `lastname` varchar(156) NOT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `roleId` tinyint(4) NOT NULL,
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `createdBy` int(11) NOT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `username`, `firstname`, `lastname`, `mobile`, `roleId`, `isDeleted`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`) VALUES
(1, 'admin@plenarysoft.com', 'e10adc3949ba59abbe56e057f20f883e', 'admin', 'Forid', 'Pathan', NULL, 3, 0, 0, '2020-02-02 15:54:45', NULL, NULL),
(2, 'admin1@plenarysoft.com', 'e10adc3949ba59abbe56e057f20f883e', 'admin1', 'Forid', 'Pathan', NULL, 3, 0, 0, '2020-02-02 15:55:50', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
